window.addEventListener('load', function() {
    //首页轮播图模块
    var focus = document.querySelector('.focus');
    //获取轮播图左右侧按钮
    var prev = document.querySelector('.prev');
    var next = document.querySelector('.next');
    //鼠标经过轮播图时显示两个按钮
    focus.addEventListener('mouseenter', function() {
            prev.style.display = 'block';
            next.style.display = 'block';
            clearInterval(timer);
        })
        //鼠标离开轮播图时隐藏两个按钮
    focus.addEventListener('mouseleave', function() {
            prev.style.display = 'none';
            next.style.display = 'none';
            timer = setInterval(function() {
                next.click();
            }, 3000);
        })
        // 3.动态生成小圆圈，有几个图片，就有几个小圆圈
    var ul = focus.querySelector('ul');
    var ol = focus.querySelector('ol');
    //图片的宽度
    var imgWidth = focus.offsetWidth;
    for (var i = 0; i < ul.children.length; i++) {
        var li = document.createElement('li');
        li.setAttribute('index', i);
        ol.appendChild(li);
    }
    ol.children[0].className = 'current';
    var first = ul.children[0].cloneNode(true);
    ul.appendChild(first);
    // 点击某个小圆圈，它的底色改变，其余的不变
    for (var i = 0; i < ol.children.length; i++) {
        ol.children[i].addEventListener('click', function() {
            var index = this.getAttribute('index');

            for (var i = 0; i < ol.children.length; i++) {
                ol.children[i].className = '';
            }
            this.className = 'current';
            animate(ul, -index * imgWidth);
            num = index;
            circle = index;
        })
    }

    var num = 0; //图片跟着按钮走
    var circle = 0; //让小圆圈跟随者走
    var flag = true; //给按钮增加一个节流阀，使其不能快速点击
    next.addEventListener('click', function() {
        if (flag) {
            flag = false;
            if (num == ul.children.length - 1) {
                ul.style.left = 0;
                num = 0;
            }
            num++;
            animate(ul, -num * imgWidth, function() {
                flag = true;
            });
            circle++;
            if (circle == ol.children.length) {
                circle = 0;
            }
            for (var i = 0; i < ol.children.length; i++) {
                ol.children[i].className = '';
            }
            ol.children[circle].className = 'current';
        }

    })
    prev.addEventListener('click', function() {
        if (flag) {
            flag = false;
            if (num == 0) {
                ul.style.left = -(ul.children.length - 1) * imgWidth + 'px';
                num = ul.children.length - 1;
            }
            num--;
            animate(ul, -num * imgWidth, function() {
                flag = true;
            });
            circle--;
            if (circle < 0) {
                circle = ol.children.length - 1;
            }
            for (var i = 0; i < ol.children.length; i++) {
                ol.children[i].className = '';
            }
            ol.children[circle].className = 'current';

        }
    })
    var timer = setInterval(function() {
        next.click();
    }, 3000);
})