window.addEventListener('load', function() {
    var regtel = /^1[3|4|5|7|8]\d{9}/; //手机号码的正则表达式
    var tel = document.querySelector('#tel');
    tel.addEventListener("blur", function() {
        if (regtel.test(this.value)) {
            this.nextElementSibling.className = 'success';
            this.nextElementSibling.innerHTML = '<em><img src="images/right.png" alt=""></em> 手机号码格式正确';
        } else {
            this.nextElementSibling.className = 'error';
            this.nextElementSibling.innerHTML = '<em><img src="images/erro.png" alt=""></em> 手机号码格式不正确，请从新输入';
        }
    })
})